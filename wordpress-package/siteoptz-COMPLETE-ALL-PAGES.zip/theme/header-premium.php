<?php
/**
 * The header for SiteOptz.ai Premium Theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @package SiteOptz_Premium
 * @version 1.0.0
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <?php if (is_front_page()) : ?>
        <title><?php echo esc_html(get_theme_mod('seo_title', 'SiteOptz.ai - AI Tools Comparison Platform | Find Your Perfect AI Solution')); ?></title>
        <meta name="description" content="<?php echo esc_attr(get_theme_mod('seo_description', 'Discover and compare 1000+ AI tools with data-driven insights, personalized recommendations, and real-time pricing. Find your perfect AI solution today.')); ?>">
        <meta name="keywords" content="<?php echo esc_attr(get_theme_mod('seo_keywords', 'AI tools comparison, artificial intelligence software, AI tool finder, best AI tools 2024, AI comparison platform')); ?>">
    <?php endif; ?>
    
    <meta name="author" content="SiteOptz.ai">
    <meta name="robots" content="index, follow">
    
    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo esc_url(home_url('/')); ?>">
    <meta property="og:title" content="<?php echo esc_attr(get_theme_mod('og_title', 'SiteOptz.ai - AI Tools Comparison Platform')); ?>">
    <meta property="og:description" content="<?php echo esc_attr(get_theme_mod('og_description', 'Find your perfect AI tool with data-driven comparisons and personalized recommendations')); ?>">
    <meta property="og:image" content="<?php echo esc_url(get_theme_mod('og_image', get_template_directory_uri() . '/assets/og-image.jpg')); ?>">
    
    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="<?php echo esc_url(home_url('/')); ?>">
    <meta property="twitter:title" content="<?php echo esc_attr(get_theme_mod('twitter_title', 'SiteOptz.ai - AI Tools Comparison Platform')); ?>">
    <meta property="twitter:description" content="<?php echo esc_attr(get_theme_mod('twitter_description', 'Find your perfect AI tool with data-driven comparisons and personalized recommendations')); ?>">
    <meta property="twitter:image" content="<?php echo esc_url(get_theme_mod('twitter_image', get_template_directory_uri() . '/assets/twitter-image.jpg')); ?>">
    
    <!-- Structured Data -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "WebSite",
      "name": "<?php bloginfo('name'); ?>",
      "url": "<?php echo esc_url(home_url('/')); ?>",
      "description": "<?php bloginfo('description'); ?>",
      "potentialAction": {
        "@type": "SearchAction",
        "target": "<?php echo esc_url(home_url('/')); ?>?search={search_term_string}",
        "query-input": "required name=search_term_string"
      }
    }
    </script>
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Favicon -->
    <?php if (has_site_icon()) : ?>
        <link rel="icon" href="<?php echo esc_url(get_site_icon_url(32)); ?>" sizes="32x32">
        <link rel="icon" href="<?php echo esc_url(get_site_icon_url(192)); ?>" sizes="192x192">
        <link rel="apple-touch-icon" href="<?php echo esc_url(get_site_icon_url(180)); ?>">
    <?php endif; ?>
    
    <?php wp_head(); ?>
    
    <!-- Custom CSS from Customizer -->
    <style>
        <?php echo get_theme_mod('custom_css', ''); ?>
    </style>
</head>

<body <?php body_class(); ?>>
    
    <?php wp_body_open(); ?>
    
    <!-- Skip Links for Accessibility -->
    <a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e('Skip to content', 'siteoptz-premium'); ?></a>
    
    <div id="page" class="site">
        
        <!-- Header -->
        <header id="masthead" class="site-header" role="banner">
            <div class="container">
                <div class="header-content">
                    
                    <!-- Site Branding -->
                    <div class="site-branding">
                        <?php if (has_custom_logo()) : ?>
                            <div class="site-logo">
                                <?php the_custom_logo(); ?>
                            </div>
                        <?php else : ?>
                            <div class="logo-icon">
                                <i class="fas fa-robot"></i>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (is_front_page() && is_home()) : ?>
                            <h1 class="site-title">
                                <a href="<?php echo esc_url(home_url('/')); ?>" rel="home">
                                    <?php bloginfo('name'); ?>
                                </a>
                            </h1>
                        <?php else : ?>
                            <p class="site-title">
                                <a href="<?php echo esc_url(home_url('/')); ?>" rel="home">
                                    <?php bloginfo('name'); ?>
                                </a>
                            </p>
                        <?php endif; ?>
                        
                        <?php
                        $description = get_bloginfo('description', 'display');
                        if ($description || is_customize_preview()) :
                        ?>
                            <p class="site-description"><?php echo $description; ?></p>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Main Navigation -->
                    <nav id="site-navigation" class="main-navigation" role="navigation" aria-label="<?php esc_attr_e('Primary menu', 'siteoptz-premium'); ?>">
                        
                        <?php if (has_nav_menu('primary')) : ?>
                            <?php
                            wp_nav_menu(array(
                                'theme_location' => 'primary',
                                'menu_id'        => 'primary-menu',
                                'container'      => false,
                                'depth'          => 2,
                                'fallback_cb'    => false,
                            ));
                            ?>
                        <?php else : ?>
                            <!-- Default Menu if none is set -->
                            <ul id="primary-menu">
                                <li><a href="<?php echo esc_url(home_url('/')); ?>">Home</a></li>
                                <li><a href="<?php echo esc_url(home_url('/tools')); ?>">AI Tools</a></li>
                                <li><a href="<?php echo esc_url(home_url('/comparisons')); ?>">Compare</a></li>
                                <li><a href="<?php echo esc_url(home_url('/pricing')); ?>">Pricing</a></li>
                                <li><a href="<?php echo esc_url(home_url('/blog')); ?>">Blog</a></li>
                                <li><a href="<?php echo esc_url(home_url('/contact')); ?>">Contact</a></li>
                            </ul>
                        <?php endif; ?>
                        
                        <!-- Header CTA Button -->
                        <?php 
                        $header_cta_text = get_theme_mod('header_cta_text', 'Get Started');
                        $header_cta_url = get_theme_mod('header_cta_url', '#get-started');
                        $show_header_cta = get_theme_mod('show_header_cta', true);
                        
                        if ($show_header_cta) :
                        ?>
                            <a href="<?php echo esc_url($header_cta_url); ?>" class="header-cta">
                                <?php echo esc_html($header_cta_text); ?>
                                <i class="fas fa-arrow-right"></i>
                            </a>
                        <?php endif; ?>
                        
                        <!-- Mobile Menu Toggle (for future implementation) -->
                        <button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false" style="display: none;">
                            <span class="screen-reader-text"><?php esc_html_e('Primary Menu', 'siteoptz-premium'); ?></span>
                            <i class="fas fa-bars"></i>
                        </button>
                        
                    </nav>
                    
                </div>
            </div>
        </header>
        
        <!-- Main Content Wrapper -->
        <div id="content" class="site-content">